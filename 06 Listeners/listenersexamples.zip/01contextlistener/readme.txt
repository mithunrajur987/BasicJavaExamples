There is no servlet or jsp for this application
This is just a demo for context object creation event and listener.
So just deploy the application and see the output of ServletContextListener 
getting executed.
